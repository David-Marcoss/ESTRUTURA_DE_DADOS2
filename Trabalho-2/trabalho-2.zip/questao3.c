#include<stdio.h>
#include<stdlib.h>
#include<ctype.h>

void traco(){
	printf("\n===================================================================================================\n");
}


typedef struct{

	int I_bloco,F_bloco;  //I_bloco= Inicio do Bloco ,F_bloco = Fim do bloco
	char estado;         // Estado do bloco ('o' = ocupado , 'l' = livre)

}bloco;

typedef struct b{

	bloco info1,info2;
	struct b *esq,*cen,*dir;
	int Ninfos;

}arvore23;

int hefolha(arvore23 *No){
	int flag = 0;

	if (No != NULL){
		if (No->esq == NULL && No->cen == NULL && No->dir == NULL)
			flag = 1;
	}
	
	return flag;
}

void criaNo(arvore23 **No, bloco info, arvore23 *esq, arvore23 *cen ){ //recebe um No e uma info e cria um novo No

	*No = (arvore23 *)malloc(sizeof(arvore23));

	(*No)->info1 = info;
	(*No)->Ninfos = 1;
	(*No)->esq = esq;
	(*No)->cen = cen;
	(*No)->dir = NULL;
}

void adicionaNo(arvore23 **No, bloco info, arvore23 *filho){ /*quando o No tem espaço, adiciona a info no No
														    filho pode ser NULL ou ele sera o No com a maior
														    info apos a quebra de um No
														  */ 
	if (info.I_bloco > (*No)->info1.I_bloco ){ 
		(*No)->info2 = info;
		(*No)->dir = filho;
		
	}else{ //caso em que a info é menor que a info1 do No

		(*No)->info2 = (*No)->info1;
		(*No)->info1 = info;
		(*No)->dir = (*No)->cen;
		(*No)->cen = filho;


	}

	(*No)->Ninfos = 2;

}

void quebraNo(arvore23 **No,bloco info, bloco *sobe, arvore23 **No_maior,  arvore23 *filho){ /*recebe um No e uma info
																						e um filho que pode ser NUll ou nao
																						e devolve na variavel sobe:a informação que sobe
																						No_maior: o No criado com a maior info e no
																						No fica a menor info*/

	if (info.I_bloco < (*No)->info1.I_bloco ){ // o do meio é a info1
		
		*sobe = (*No)->info1;
		(*No)->info1 = info;
		criaNo(No_maior,(*No)->info2,(*No)->cen,(*No)->dir);
		(*No)->cen = filho;
		

	}else if (info.I_bloco < (*No)->info2.I_bloco ){ // o do meio é a info
		*sobe = info; 
		criaNo(No_maior,(*No)->info2,filho,(*No)->dir); //modificação
	

	}else{ 
		*sobe = (*No)->info2;
		criaNo(No_maior,info,(*No)->dir,filho);
	}

	(*No)->dir = NULL;
	(*No)->Ninfos = 1;


}

struct b* insere(arvore23 **Pai,arvore23 **Raiz ,bloco info, bloco *sobe){ /* recebe um No pai incia sempre com NULL
																		A Raiz e uma info e insere a info na arvore*/
	arvore23 *No_maior;
	No_maior = NULL;

	if (*Raiz == NULL){
		criaNo(Raiz,info,NULL,NULL);

	}else{

		if (hefolha(*Raiz) == 1){
			
			if ((*Raiz)->Ninfos == 1){
				adicionaNo(Raiz,info,NULL);
			
			}else{
				
				quebraNo(Raiz,info,sobe,&No_maior,NULL);

				if (*Pai == NULL){
					arvore23 *aux;
					criaNo(&aux,*sobe,*Raiz,No_maior);

					*Raiz = aux;

					No_maior = NULL;
				}
			}
		
		}else {

			if (info.I_bloco < (*Raiz)->info1.I_bloco ){
			    No_maior= insere(Raiz,&(*Raiz)->esq,info,sobe);
			
		    }else if ((*Raiz)->Ninfos == 2 && info.I_bloco > (*Raiz)->info2.I_bloco){
			    No_maior= insere(Raiz,&(*Raiz)->dir,info,sobe);
		   	
		   	}else{
			    No_maior= insere(Raiz,&(*Raiz)->cen,info,sobe);
		    }

			if (No_maior != NULL){

				if ((*Raiz)->Ninfos == 1){
					adicionaNo(Raiz,*sobe,No_maior);			
					No_maior = NULL;
					
				}else{
					bloco sobe2;
					arvore23 *No_maior2;
			
					quebraNo(Raiz,*sobe,&sobe2,&No_maior2,No_maior);

					if (*Pai == NULL){
						arvore23 *aux;

						criaNo(&aux,sobe2,*Raiz,No_maior2);
						*Raiz = aux;
						No_maior = NULL;
					
					}else{
						*sobe = sobe2;
						No_maior= No_maior2;
					}
				}
			}
			
		}
	}

	return No_maior;

}

void flush_in(){ 
int ch;
while( (ch = fgetc(stdin)) != EOF && ch != '\n' ){} 

}

void imprimir_bloco(bloco b){

	printf("bloco: %d , %d -%c\n",b.I_bloco,b.F_bloco,b.estado);

}

struct b* busca_Menor_No(arvore23 **No){  //recebe um No e perrcore a partir desse No busca
										 // e retorna o No com a menor info
	arvore23 *aux;													  

	if ((*No)->esq != NULL)
		aux = busca_Menor_No(&(*No)->esq);
	else
		aux = *No;

	return aux;
	
}

/*função ocupa espaço nao trata os casos em que 
é encontardo um No com a quantidade exata de memoria livre e
é nescessario concatenar Nos*/

void ocupa_espaco(arvore23 **Pai ,arvore23 **Raiz, int Tam_bloco, int *flag){ /*recebe o pai que inicia com Null a raiz da arvore 
																			 e a quantidade de bloco que se deseja ocupar esta função irar 
																			 a info com a quantidade livre nescessaria e se encontar o cupa o espaço
																			 se nao encontrar devolve 0 em flag para indicar que nao foi possivel realizar operação*/
   
	
	if(*Raiz != NULL && *flag != 1 ){
		
		if ( (*Raiz)->info1.estado == 'l' && ((*Raiz)->info1.F_bloco - (*Raiz)->info1.I_bloco +1) > Tam_bloco){ //caso em que o bloco livre encontrado
			*flag = 1;																						// possui mais espaço do que o desejado e é a info1 do No

			if (hefolha(*Raiz) == 1){

				if ((*Raiz)->Ninfos == 1 && *Pai == NULL){ 	//caso em que é a Raiz da arvore e so tem uma info
					(*Raiz)->info2.F_bloco = (*Raiz)->info1.F_bloco;
					(*Raiz)->info1.F_bloco -= Tam_bloco;
					(*Raiz)->info2.I_bloco = (*Raiz)->info1.F_bloco + 1;
					(*Raiz)->info2.estado = 'o';
					(*Raiz)->Ninfos = 2;
					
				}else if ((*Raiz)->Ninfos == 2){
					(*Raiz)->info1.F_bloco -= Tam_bloco;
					(*Raiz)->info2.I_bloco = (*Raiz)->info1.F_bloco + 1; 
				
					
				}else{
					
					if ((*Raiz)->info1.I_bloco < (*Pai)->info1.I_bloco ){
						(*Raiz)->info1.F_bloco -= Tam_bloco;
						(*Pai)->info1.I_bloco = (*Raiz)->info1.F_bloco + 1;

					}else{
						(*Raiz)->info1.I_bloco += Tam_bloco;

						if((*Raiz) == (*Pai)->cen) 
							(*Pai)->info1.F_bloco += Tam_bloco;	
						else
							(*Pai)->info2.F_bloco += Tam_bloco;;
					
					}

				}
			
			}else{
				arvore23 *aux;

				(*Raiz)->info1.F_bloco -= Tam_bloco;
				aux = busca_Menor_No(&(*Raiz)->cen);

				aux->info1.I_bloco = (*Raiz)->info1.F_bloco + 1;

			}

		}else if ( (*Raiz)->info1.estado == 'l' && ((*Raiz)->info1.F_bloco - (*Raiz)->info1.I_bloco + 1) == Tam_bloco){ //caso em que o bloco livre encontrado
																													// possui exatamente o espaço do que o desejado e é a info1 do No
			*flag = 1;
				
			if (hefolha(*Raiz) == 1){

				if (*Pai == NULL){	//caso em que é a Raiz da arvore

					if ((*Raiz)->Ninfos == 2){
						(*Raiz)->info2.I_bloco = (*Raiz)->info1.I_bloco;
						(*Raiz)->info1 = (*Raiz)->info2;
						(*Raiz)->Ninfos = 1;
						
					}else{
						(*Raiz)->info1.estado = 'o'; 
					}
					
				}else{
					//caso em que tem que concatenar
				}
			
			}
		
		}else if ( (*Raiz)->Ninfos == 2 && (*Raiz)->info2.estado == 'l' && ((*Raiz)->info2.F_bloco - (*Raiz)->info2.I_bloco + 1) > Tam_bloco){ //caso em que o bloco livre encontrado
			*flag = 1;																													// possui mais espaço do que o desejado e é a info2 do No
			
			if(hefolha(*Raiz) == 1){
				(*Raiz)->info2.I_bloco += Tam_bloco;
				(*Raiz)->info1.F_bloco += Tam_bloco;
			
			}else{
				arvore23 *aux;

				(*Raiz)->info2.F_bloco -= Tam_bloco;
				
				aux = busca_Menor_No(&(*Raiz)->dir);

				aux->info1.I_bloco = (*Raiz)->info2.F_bloco + 1;
			}

		}else if ( (*Raiz)->Ninfos == 2 && (*Raiz)->info2.estado == 'l' && ((*Raiz)->info2.F_bloco - (*Raiz)->info2.I_bloco + 1) == Tam_bloco){
			*flag = 1;

			if (hefolha(*Raiz) == 1){
				(*Raiz)->info1.F_bloco = (*Raiz)->info2.F_bloco;
				(*Raiz)->Ninfos = 1;

			}else{
				//caso em que tem que concatenar
			}

		}

		
		ocupa_espaco(Raiz,&(*Raiz)->esq,Tam_bloco,flag);
		ocupa_espaco(Raiz,&(*Raiz)->cen,Tam_bloco,flag);
		ocupa_espaco(Raiz,&(*Raiz)->dir,Tam_bloco,flag);			
	}

}

void inserir_valores(arvore23 **Raiz, int quant_blocos){

	arvore23 *Pai;
	bloco info,sobe;

	info.I_bloco = info.F_bloco = 0;

	traco();
	flush_in();
	printf("digite o estado do primeiro bloco(o = ocupado ou l = livre): ");
	scanf("%c",&info.estado);
	flush_in();

	tolower(info.estado);

	while(info.estado != 'o' && info.estado != 'l' ){
		printf("\ndigite um estado valido!!\n");
		printf("digite o estado do primeiro bloco(o = ocupado ou l = livre): ");
		scanf("%c",&info.estado);
		flush_in();

	}

	while(info.F_bloco < quant_blocos-1){

		Pai = NULL;

		traco();
		
		printf("\ninicio do bloco: %d\n",info.I_bloco);
		printf("digite o fim do bloco: ");
		scanf("%d",&info.F_bloco);

		while(info.F_bloco >= quant_blocos || info.F_bloco < info.I_bloco ){
			
			printf("\nValor invalido\n");
			printf("digite um valor valido para o fim do bloco(Espaco disponivel: %d): ",quant_blocos -info.I_bloco );
			scanf("%d",&info.F_bloco);
		}

		insere(&Pai,Raiz,info,&sobe);

		info.I_bloco = info.F_bloco + 1;

		if (info.estado == 'l')
			info.estado = 'o';
		else 
			info.estado = 'l';

	}
		
}

void imprimir(arvore23 *Raiz){

		if(Raiz != NULL){
			imprimir(Raiz->esq);

			imprimir_bloco(Raiz->info1);

			imprimir(Raiz->cen);

			if(Raiz->Ninfos == 2){
			    imprimir_bloco(Raiz->info2);
			}

			imprimir(Raiz->dir);


		}

}

int menu(){ //imprime menu
	int op;
	
	traco();
	printf("1- imprimir arvore \n");
	printf("2- Ocupar spaco \n");
	printf("3- sair \n");
	printf("\ndigite opcao: ");
	scanf("%d",&op);

	return op;
}



int main(){
	arvore23 *Raiz = NULL,*Pai;

	int op,n,flag,quant_blocos;

	traco();

	printf("\ndigite o tamanho da memoria em Mbyte: ");
	scanf("%d",&quant_blocos);

	while(quant_blocos <= 0){
		printf("\ndigite uma quantidade valida!!\n");
		printf("\ndigite o tamanho da memoria em Mbyte: ");
		scanf("%d",&quant_blocos);
	}

	inserir_valores(&Raiz,quant_blocos);

	do{
		
		op = menu();

		switch (op){

			case 1:
				traco();
				
				imprimir(Raiz);
				
				break;

			case 2:
				flag = 0;
				Pai = NULL;
				traco();

				printf("\ndigite o tamanho do bloco que voce deseja ocupar: ");
				scanf("%d",&n);

				ocupa_espaco(&Pai,&Raiz,n,&flag);

				if (flag == 0){
					printf("\nquantidade de blocos informada não existe livre!!Nao e possível alocar essa quantidade de blocos.\n");
				
				}else{
					printf("\nOperacao concluida!!\n");
				}

				

				break;

			case 3:

				printf("\nSaindo.....\n");
			
				break;		
			
			default:
				printf("\nopcao invalida!!!\n");

				break;
			

		}


	}while(op != 3);
	


	return 0;
}
